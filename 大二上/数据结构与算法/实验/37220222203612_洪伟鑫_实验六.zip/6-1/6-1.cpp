#include<iostream>
using namespace std;
string flag = "12002102001201200100210102";
int a[3];
void sorting(string &flag) {
	int n = flag.size();
	for (int i = 0; i < n; i++) {
		a[flag[i] - '0']++;
	}
	for (int i = 0, index = 0; i < 3; i++) {
		for (int j = 0; j < a[i]; j++) {
			flag[index++] = i + '0';
		}
	}
}
void display(string a) {
	cout << a << endl;
}
int main()
{
	display(flag);
	cout << "----------------------------------" << endl;
	sorting(flag);
	display(flag);
	return 0;
}
