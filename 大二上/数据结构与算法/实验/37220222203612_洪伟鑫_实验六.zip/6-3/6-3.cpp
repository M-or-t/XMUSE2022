#include<iostream>
#include<cmath>
#include<algorithm>

using namespace std;
const int N = 8;
int a[N] = { 543,632,43257,3435,2137,436,341,56789 };

void InitTree(int a[], int n) {
    for (int i = n - 1; i > 0; --i) {
        for (int j = (i + 1) / 2 - 1; j >= 0; --j) {
            int lc = 2 * j + 1;
            int rc = 2 * j + 2;

            int min = j;

            if (lc < i && a[lc] < a[min]) {
                min = lc;
            }

            if (rc < i && a[rc] < a[min]) {
                min = rc;
            }

            if (min != j) {
                swap(a[j], a[min]);
            }
        }
    }
}

void treeSelectionSort(int a[], int n) {
    InitTree(a, n);//����
    for (int i = n - 1; i > 0; --i) {
        swap(a[0], a[i]);

        for (int j = (i + 1) / 2 - 1; j >= 0; --j) {
            int lc = 2 * j + 1;
            int rc = 2 * j + 2;

            int min = j;

            if (lc < i && a[lc] < a[min]) {
                min = lc;
            }
            if (rc < i && a[rc] < a[min]) {
                min = rc;
            }
            if (min != j) {
                swap(a[j], a[min]);
            }
        }
    }//n-1�ε�����ÿ�ΰ�����ֵŲ����
}

void display(int a[]) {
    for (int i = 0; i < N;i++) {
        cout << a[i] << " ";
    }
    cout << endl;
    cout << "--------------------------------------" << endl;
}
int main() {
    display(a);
    treeSelectionSort(a, N);
    display(a);
	return 0;
}
