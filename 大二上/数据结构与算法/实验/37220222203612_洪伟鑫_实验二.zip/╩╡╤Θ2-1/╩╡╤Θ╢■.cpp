﻿#include<iostream>
#include<queue>
#include<algorithm>
using namespace std;
typedef int type;
#define ERROR false;
#define OK true;
typedef bool Status;
typedef struct BiTNode {
	type data;
	struct BiTNode* Lchild;
	struct BiTNode* rchild;
}BiTNode, * BiTree;

Status InitBiTree(BiTree& T) {
	T = (BiTree)malloc(sizeof(BiTNode));
	if (!T)return ERROR;
	T->Lchild = nullptr;
	T->rchild = nullptr;
	return OK;
}

void DestroyBiTree(BiTree& T) {
	if (!T)return;
	DestroyBiTree(T->Lchild);
	DestroyBiTree(T->rchild);
	free(T);
	return;
}

void CreateBiTree(BiTree& T) {
	int  n;
	cin >> n;
	if (n == -1) {
		T = nullptr;
	}
	else {
		T = (BiTNode*)malloc(sizeof(BiTNode));
		T->data = n;
		CreateBiTree(T->Lchild);
		CreateBiTree(T->rchild);
	}
}

void ClearBiTree(BiTree& T) {
	DestroyBiTree(T->Lchild);
	DestroyBiTree(T->rchild);
	T = nullptr;
}

Status BiTreeEmpty(BiTree& T) {
	if (!T)return OK;
	return ERROR;
}

int BiTreeDepth(BiTree& T) {
	if (!T)return 0;
	return max(BiTreeDepth(T->Lchild), BiTreeDepth(T->rchild)) + 1;
}

BiTree Root(BiTree& T) {
	if (!T)return nullptr;
	return T;
}

int Value(BiTree& T, BiTNode*& e) {
	if (!T)return 0;
	if (T == e)return e->data;
	int l = Value(T->Lchild, e);
	if (l == e->data)return e->data;
	int r = Value(T->rchild, e);
	if (r == e->data)return e->data;
}

void Assign(BiTree& T, BiTNode*& e, int value) {
	if (!T)return ;
	if (T == e) {
		e->data = value;
		return;
	}
	Assign(T->Lchild, e, value);
	Assign(T->rchild, e, value);
	return;
}

BiTNode* Parent(BiTree& T, BiTNode* &e) {
	BiTNode* q = nullptr;
	if (T == nullptr || e == T) {
		return nullptr;
	}
	else {
		if (T->Lchild == e || T->rchild == e) {
			return T;
		}
		q = Parent(T->Lchild, e);
		if (q == nullptr) {
			q = Parent(T->rchild, e);
			return q;
		}
	}
	return q;
}

BiTNode* LeftChild(BiTree& T, BiTNode* &e) {
	if (T != nullptr && e != nullptr) {
		return e->Lchild;
	}
	else {
		return nullptr;
	}
}

BiTNode* RightChild(BiTree& T, BiTNode* &e) {
	if (T!= nullptr &&e != nullptr) {
		return e->rchild;
	}
	else {
		return nullptr;
	}
}

BiTNode* LeftSibling(BiTree& T, BiTNode* &e) {
	if (T == nullptr) {
		return nullptr;
	}
	else {
		BiTNode* q = Parent(T, e);
		if (q != nullptr && q->Lchild != e) {
			return q->Lchild;
		}
		else {
			return nullptr;
		}
	}
	return nullptr;
}

BiTNode* RightSibling(BiTree& T, BiTNode* &e) {
	if (T == nullptr) {
		return nullptr;
	}
	else {
		BiTNode* q = Parent(T, e);
		if (q != nullptr && q->rchild != e) {
			return q->rchild;
		}
		else {
			return nullptr;
		}
	}
	return nullptr;
}

void InsertChild(BiTree& T, BiTNode* p, int LR, BiTree& c) {
	if (T == nullptr || p == nullptr || c == nullptr) {
		return;
	}
	else {
		if (LR == 0) {
			c->rchild = p->Lchild;
			p->Lchild = c;
		}
		else {
			c->rchild = p->rchild;
			p->rchild = c;
		}
	}
	return;
}

void DeleteChild(BiTree& T, BiTNode* p, int LR) {
	if (T == nullptr || p == nullptr) {
		return;
	}
	if (LR == 0) {
		DestroyBiTree(p->Lchild);
		p->Lchild = nullptr;
	}
	else {
		DestroyBiTree(p->rchild);
		p->rchild = nullptr;
	}
}

void PreOrderTraverse(BiTree& T) {
	if (!T)return;
	cout << T->data << " ";
	PreOrderTraverse(T->Lchild);
	PreOrderTraverse(T->rchild);
}

void InOrderTraverse(BiTree& T) {
	if (!T)return;
	InOrderTraverse(T->Lchild);
	cout << T->data << " ";
	InOrderTraverse(T->rchild);
}

void PostOrderTraverse(BiTree& T) {
	if (!T)return;
	PostOrderTraverse(T->Lchild);
	PostOrderTraverse(T->rchild);
	cout << T->data << " ";
}

void LevelOrderTraverse(BiTree& T) {
	queue<BiTNode*>tree;
	if (!T)return;
	tree.push(T);
	while (!tree.empty()) {
		int n = tree.size();
		for (int i = 0; i < n; i++) {
			BiTree temp = tree.front();
			tree.pop();
			cout << temp->data << " ";
			if (temp->Lchild)tree.push(temp->Lchild);
			if (temp->rchild)tree.push(temp->rchild);
		}
		
	}
	return;
}
int main() {
	BiTree T;
	InitBiTree(T);
	bool flag = BiTreeEmpty(T);
	cout << flag << endl;
	if (!flag)cout << "空树" << endl;
	CreateBiTree(T);
	int d = BiTreeDepth(T);
	PreOrderTraverse(T);
	cout << endl;
	InOrderTraverse(T);
	cout << endl;
	PostOrderTraverse(T);
	cout << endl;
	LevelOrderTraverse(T);
	cout << endl;
	return 0;
}