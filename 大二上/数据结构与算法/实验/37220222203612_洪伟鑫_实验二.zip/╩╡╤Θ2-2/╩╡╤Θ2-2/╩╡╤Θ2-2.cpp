﻿#include<iostream>
#include<cstring>
#define _CRT_SECURE_NO_WARNINGS 
#pragma warning(disable:4996)
using namespace std;
typedef struct HTNode{
	char data;
	int wt;
	int np;
	int nl;
	int nr;
}*htree;
//Select函数 
void Select(htree HT, int end, int* s1, int* s2) {
	int min1, min2;//min1存放较小的，min2存放第二小的,min1<min2
	//先挑选出一个双亲结点为0的结点 ，如果双亲节点不为0说明这个结点已经在生成新节点中被使用过 
	int i = 1;
	while (HT[i].np != 0 && i <= end) {
		i++;
	}
	//将第一次挑选出来的结点的权值先赋值给min1，然后i加一，挑选第二个双亲结点为0的结点
	min1 = HT[i].wt;
	*s1 = i;
	i++;
	// 挑选第二个双亲结点为0的结点
	while (HT[i].np != 0 && i <= end) {
		i++;
	}
	if (HT[i].wt < min1) {
		min2 = min1;
		*s2 = *s1;
		min1 = HT[i].wt;
		*s1 = i;
	}
	else {
		min2 = HT[i].wt;
		*s2 = i;
	}
	//对余下的结点进行遍历
	for (int j = i + 1; j <= end; j++) {
		if (HT[j].np != 0) continue;
		if (HT[j].wt < min1) {
			min2 = min1;
			min1 = HT[j].wt;
			*s2 = *s1;
			*s1 = j;
		}
		//如果 min1<=HT[i].wt<=min2,则 将HT[j].wt的值赋给min2
		else if (HT[j].wt >= min1 && HT[j].wt < min2) {
			min2 = HT[j].wt;
			*s2 = j;
		}

	}
}
void CreateHuffmanTree(htree& HT, int n) {
	if (n <= 1)  return;
	int m = 2 * n - 1;
	HT = new HTNode[m + 1]; //0单元号未用，下标从1开始 
	for (int i = 1; i <= m; i++) { //初始化，将下标1~m号结点的双亲，左孩子，右孩子置为0 
		HT[i].np = 0;
		HT[i].nl= 0;
		HT[i].nr = 0;
	}
	for (int i = 1; i <= n; i++) {
		cin >> HT[i].wt;  //输入前n个结点的权值 
	}
	//初始化根节点集合，然后创建哈夫曼树
	for (int i = n + 1; i <= m; i++) {
		//通过n-1次合并，构建哈夫曼树
		int s1 = 0, s2 = 0;
		Select(HT, i - 1, &s1, &s2);
		/* 在select中挑选出两个权值较小的结点，且s1<s2；
		 合并成一个新的结点，新的结点的结点号为i ,此时s1和s2结点的双亲结点即为i */
		HT[s1].np = i; HT[s2].np = i;
		HT[i].nl = s1;//将s1和s2分别作为结点i的左右孩子 
		HT[i].nr = s2;
		HT[i].wt = HT[s1].wt + HT[s2].wt;//结点i的权值为左右孩子之和 
	}
}
typedef char** HuffmanCode;//动态分配数组存储哈夫曼编码表

void CreateHuffmanCode(htree HT, HuffmanCode& HC, int n) {
	//得到哈夫曼编码 
	int start, c, f;
	HC = new char* [n + 1];      //下表从1开始，分配存储n个字符编码的编码表空间
	char* cd = new char[n];  
	cd[n - 1] = '\0';        //编码结束
	for (int i = 1; i <= n; i++) {    //逐个字符求哈夫曼编码 
		start = n - 1;            //start开始指向最后，即编码结束符的位置 
		c = i; f = HT[i].np;   //f指向结点c的双亲结点,
		while (f != 0) {
			start--;           //回溯一次，start位置向前指一个位置 
			if (HT[f].nl == c) cd[start] = '0'; //如果结点c是f的左孩子，则生成代码0 
			else cd[start] = '1';                //如果结点c是f的右孩子，则生成代码0 
			c = f; f = HT[f].np;                //继续向上回溯，直至 f的双亲为0回溯结束 
		}
		HC[i] = new char[n - start];  
		strcpy(HC[i], &cd[start]); //为第i个字符编码分配空间 
	}
	delete cd;                    //释放临时空间 
}

int main() {
	htree HT;
	HuffmanCode HC;
	CreateHuffmanTree(HT, 5);//创建含有5条带权路径的哈夫曼树
	CreateHuffmanCode(HT, HC, 5);//进行编码
	for (int i = 1; i <= 5; i++) {
		//编码输出
		cout << HC[i] << endl;
	}
	return 0;
}