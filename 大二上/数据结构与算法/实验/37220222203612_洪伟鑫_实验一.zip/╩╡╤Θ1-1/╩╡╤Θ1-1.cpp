﻿#include<iostream>
using namespace std;
typedef int type;
typedef bool Status;
typedef int ElemType;
#define OK true;
#define ERROR false;

typedef struct Node {
	type data;
	 Node* next;
}Node, * Link,*Position;

typedef struct Linklist{
	Link head;
	Link tail;
	int len;
};

Status MakeNode(Link& p, ElemType e) {
	p = (Link)malloc(sizeof(Node));
	if (!p) return ERROR;
	p->data = e;
	p->next = nullptr;  // 确保 next 成员初始化为 nullptr
	return OK;
}


void FreeNode(Link& p) {
	free(p);
	p = nullptr;
	return;
}//释放结点后，指向空

Status InitList(Linklist& L) {
	L.head = (Link)malloc(sizeof(Node));
	if (!L.head) {
		L.tail = nullptr;
		L.len = 0;
		return OK;
	}
	L.head->next = nullptr;
	L.tail = L.head;
	L.len = 0;
	return OK;
}

void ClearList(Linklist& L) {
	Link p, q;
	if (L.head != L.tail)//如果本来不是空表的话
	{
		p = q = L.head->next;
		L.head->next = nullptr;//先断掉链表，并清空断掉的表
		while (p != L.tail) {
			p = q->next;
			FreeNode(q);
			q = p;
		}
		q = nullptr;
		FreeNode(p);
		L.tail = L.head;//清空整条链表后，将链表尾指针重置，并重置长度
		L.len = 0;
	}
	else return;
}

void DetroyList(Linklist& L) {
	ClearList(L);
	FreeNode(L.head);
	L.tail = nullptr;
	L.len = 0;
	return;//使Linklist链表头、尾均指向空
}

void InsFirst(Linklist& L, Link h, Link s) {
	s->next = h->next;
	h->next = s;
	if (h == L.tail) L.tail = s;
	if (L.tail->next != nullptr) L.tail = s;  // 如果原本头尾指针相连，插入后尾指针应该指向第一个节点（即插入的 s）
	L.len++;
}


Link DelFirst(Linklist& L, Link h) {
	if (h->next == nullptr)
		return nullptr;  // 先判断是否链表为空，若为空，则不能删除，返回空，即没有删除 q 结点
	Link q = h->next;
	h->next = h->next->next;
	if (h->next == nullptr)  // 如果删除的是尾结点，更新链表的尾指针
		L.tail = h;
	Link r = new Node;
	r->data = q->data;
	r->next = nullptr;
	FreeNode(q);
	return r;  // 返回被删除的结点 q 的副本。
}




void Append(Linklist& L, Link s) {
	int count = 0;
	Link p = L.tail;
	L.tail->next = s;
	while (p->next != nullptr) {
		p = p->next;
		count++;
	}
	L.tail = p;
	L.len += count;
}

Status Remove(Linklist& L,Link &q) {
	q = L.tail;
	if (L.head == L.tail) {
		return ERROR;//如果是空表，没有尾结点，删除失败
	}
	else {
		Link p = L.head;//否则，找到尾结点的前驱结点，进行删除
		while (p->next != L.tail) {
			p = p->next;
		}
		FreeNode(L.tail);
		L.tail = p;
		p->next = nullptr;
		L.len--;
		return OK;
	}
}

Status InsBefore(Linklist& L,Link &p,Link s) {
	Link q = L.head;
	while (q->next != p&&q!=nullptr) {
		q = q->next;
	}
	if (q == nullptr) {
		return ERROR;
	}
	else {
		s->next = p;
		q->next = s;
		p = s;
		return OK;
	}
}

void InsAfter(Linklist& L, Link& p, Link s) {
	if (p == L.tail) {
		s = p->next;
		L.tail = p;
		L.len++;
	}
	else {
		s->next = p->next;
		p->next = s;
		L.len++;
		p = s;
	}
}

Status SetCurElem(Link& p, ElemType e) {
	if (p == nullptr) {
		return ERROR;
	}
	else {
		p->data = e;
		return OK;
	}
}

ElemType GetCurElem(Link p) {
	return p->data;
}

Status ListEmpty(Linklist L) {
	if (L.len)return ERROR;
	return OK;
}

int ListLength(Linklist L){
	return L.len;
}

Position GetHead(Linklist L)
{
	return L.head;
}

Position GetLast(Linklist L)
{ 
	return L.tail;
}

Position NextPos(Link p)
{ 
	return p->next;
}

Position PriorPos(Linklist L, Link p) {
	Link q = L.head->next;//设q为L表的第一个结点，若q即为p，说明p无前驱结点
	if (q == p)return nullptr;
	while (q->next != p) {
		q = q->next;
	}
	return q;
}

Status LocatePos(Linklist L, int i, Link& p) {
	if (i < 0 || i>L.len) {
		return ERROR;
	}//先判断位置i是否合法
	else {
		p = L.head;
		for (int j = 0; j < i; j++) {
			p = p->next;
		}
		return OK;
	}
}

Status LocateElem(Linklist L, ElemType e, Status(*compare)(ElemType, ElemType)) {
	Link p=L.head;
	for (int i = 0; i < L.len; i++) {
		p = p->next;
		if ((*compare)(e, p->data))
			return OK;
	}//循环遍历链表，如果满足compare则直接返回OK，如果遍历完还不满足则直接返回ERROR;
	p = nullptr;
	return ERROR;
}

void LinklistTraverse(Linklist L, Status(*visit)(ElemType)) {
	Link p = L.head;
	for (int i = 0; i < L.len; i++) {
		p = p->next;
		visit(p->data);
	}
	return;
}

Status RingList(Linklist L) {//判断链表中是否有环，如果有环快慢指针必相交，否则的话快指针q会先到达表尾
	Link p = L.head->next;
	Link q = L.head->next;
	while (p && q&&q->next) {
		p = p->next;
		q = q->next->next;
		if (p == q)return OK;
	}
	return ERROR;
}

void Reverse(Linklist& L) {
	if (L.head == L.tail) return;
	Link p = L.head->next;
	Link q = L.tail;
	int num = L.len / 2;
	while (num--) {
		swap(p->data, q->data);
		p = p->next;
		q = PriorPos(L, q);
	}
}

int main() {
	Linklist L;
	ElemType e;

	if (InitList(L)) {
		cout << "链表初始化成功。" << endl;
	}
	else {
		cout << "链表初始化失败。" << endl;
		return 1;
	}

// 演示插入操作
	for (int i = 1; i <= 5; i++) {
		Link node;
		if (!MakeNode(node, i * 10)) {
			cout << "插入失败。" << endl;
			return 1;
		}
		InsFirst(L, L.head, node);  // 传入头结点的指针
	}


	cout << "原始链表：";
	Link p = L.head;
	while (p->next) {
		p = p->next;
		cout << p->data << " ";
	}
	cout << endl;

	int deletePosition = 1;
	Link deletedNode;
	if ((deletedNode = DelFirst(L, L.head)) != nullptr) {
		cout << "删除位置为 " << deletePosition << " 的元素：" << deletedNode->data << endl;
		FreeNode(deletedNode);
	}
	else {
		cout << "删除失败。" << endl;
		return 1;
	}


	cout << "删除后的链表：";
	p = L.head->next;
	while (p) {
		cout << p->data << " ";
		p = p->next;
	}
	cout << endl;

	// 演示反转操作
	Reverse(L);

	cout << "反转后的链表：";
	p = L.head->next;
	while (p) {
		cout << p->data << " ";
		p = p->next;
	}
	cout << endl;

	DetroyList(L);

	return 0;
}
