#include<iostream>
#include<queue>
using namespace std;
const int maxvnum = 32767;
const int maxnum = 100;
bool dvisited[maxnum];
bool bvisited[maxnum];
queue<int>visited;
typedef struct graph {
	char vexs[maxnum];
	int  arcs[maxnum][maxnum];
	int vexnum, arcnum;
	int graphtype;
}graph;
void creategraph(graph* &g) {

		cout << "���붥�����ͱ���" << endl;
		cin >> g->vexnum >> g->arcnum;
		cout << "���������������" << endl;
		for (int i = 1; i <= g->vexnum; i++) {
			cin >> g->vexs[i];//���붥�㼯
		}
		cout << "ͼ������" << endl;
		cin >> g->graphtype;
		for (int i = 1; i <= g->vexnum; i++) {
			for (int j = 1; j <= g->vexnum; j++) {
				g->arcs[i][j] = -1;//��ʼ���ڽӾ���
			}
		}
			cout << "������������߹����Ķ����Ȩֵ" << endl;
			for (int i = 0; i < g->arcnum; i++) {
				int j, k, w;
				cin >> j >> k >> w;
				g->arcs[j][k] = w;
				if (g->graphtype == 0) {
					g->arcs[k][j] = g->arcs[j][k];//����ͼ���ڽӾ����ǶԳ���
				}
			}


			cout << "----------------------------" << endl;
	return;
}
void showgraph(graph* &g) {
	int i, j;
	for (int i = 1; i <= g->vexnum; i++) {
		for (int j = 1; j <= g->vexnum; j++) {
			if (g->arcs[i][j] == -1)cout << "\u221e";
			else cout << g->arcs[i][j];
			cout << " ";
		}
		cout << endl;
	}
	cout << "----------------------------" << endl;
	return;
}
void destroygraph(graph* &g) {
	if (!g)return;
	delete g;
	return;
}
int locatevex(graph* &g, char vex) {
	for (int i = 1; i <= g->vexnum; i++) {
		if (g->vexs[i] == vex) {
			cout << "������ͼ��λ����" << i << endl;
			return 1;
		}
	}
	return 0;
}
int getvex(graph* &g, char v) {
	for (int i = 1; i <= g->vexnum; i++) {
		if (g->vexs[i] == v) {
			cout << v << "��ͼ��" << endl;
			return v;
		}
	}
	cout << "����ͼ��" << endl;
	return 0;
}
void putvex(graph* &g, char v, char value) {
	for (int i = 1; i <= g->vexnum; i++) {
		if (g->vexs[i] == v) {
			g->vexs[i] = value;
			cout << "��ͼ�ж���" << v << "�޸�Ϊ" << value << endl;
			return;
		}
	}
	cout << "�޸�ʧ��" << endl;
	return;
}
int firstadjvex(graph* &g, char v) {
	int i;
	for (i = 1; i <= g->vexnum; i++) {
		if (g->vexs[i] == v) {
			break;
		}
	}
	for (int j = 1; j <= g->vexnum; j++) {
		if (g->arcs[i][j] != -1) {
			cout <<"��һ���ڽӵĶ�����" << g->vexs[j] << endl;
			return 1;
		}
	}
	cout << "null" << endl;
	return 0;
}
void insertvex(graph* &g,char v) {
	g->vexnum++;
	g->vexs[g->vexnum] = v;
}
void insertarc(graph* &g, char v, char w) {
	int i, j;
	int value;
	cout << "������Ҫ����ıߵ�Ȩֵ" << endl;
	cin >> value;
	for (int k = 1; k <= g->vexnum; k++) {
		if (g->vexs[k] == v) {
			i = k;
		}
		if (g->vexs[k] == w) {
			j = k;
		}
	}
	if (g->graphtype == 0) {
		g->arcs[i][j] = g->arcs[j][i] = value;
	}
	else {
		g->arcs[i][j] = value;
	}
	return;
}
void deletearc(graph* &g, char v, char w) {
	int i, j;
	for (int k = 1; k <= g->vexnum; k++) {
		if (g->vexs[k] == v) {
			i = k;
		}
		if (g->vexs[k] == w) {
			j = k;
		}
	}
	if (g->graphtype == 0) {
		g ->arcs[i][j] = g->arcs[j][i] = -1;
	}
	else {
		g->arcs[i][j] = -1;
	}
	return;
}
void dfs(graph* &g,int i ) {
	cout << g->vexs[i]<<" ";
	dvisited[i] = true;
	for (int j = 1; j <= g->vexnum; j++) {
		if (g->arcs[i][j] != -1 && !dvisited[j]) {
			dfs(g, j);
		}
	}
	return;

}
void bfs(graph* &g,int i ) {
	cout << g->vexs[i]<<" ";
	bvisited[i] = true;//������㲢��Ϊ�ѷ���
	visited.push(i);//���
	while (!visited.empty()) {
		int vex = visited.front();
		visited.pop();//����Ԫ�س���
		for (int j = 1; j <= g->vexnum; j++) {
			{
				if (!bvisited[j]&&g->arcs[vex][j]!=-1) {
					cout << g->vexs[j]<<" ";
					visited.push(j);
					bvisited[j] = true;
				}//���Ѷ���Ԫ�����ڵĽ��
			}
		}
	}
	cout << "----------------------------" << endl;
	return;
}
int main() {
	graph g;
	graph* G;
	G = (graph*)malloc(sizeof(g));
	creategraph(G);
	showgraph(G);
	//locatevex(G, '1');
	//getvex(G, '1');
	/*firstadjvex(G, '1');
	putvex(G, '1', '4');
	firstadjvex(G, '4');*/
	dfs(G, 1);
	cout << "----------------------------" << endl;
	bfs(G, 1);
	return 0;
}
