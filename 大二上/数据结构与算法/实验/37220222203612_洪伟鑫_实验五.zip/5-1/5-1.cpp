#include<iostream>
using namespace std;
const int N = 100010;
int A[N];
int x;
int BiSearch(int A[], int x, int n) {
	int left = 1;
	int right = n;
	while (left <= right) {
		int mid = (left + right) >> 1;
		if (x == A[mid])return mid;
		if (x < A[mid]) {
			right = mid - 1;
		}
		else left = mid + 1;
	}
	return -1;
}
int main()
{
	cout << "��������Ԫ�صĸ���:" << endl;
	cin >> A[0];
	cout << "---------------------------------------------" << endl;
	cout << "����ÿ��Ԫ��" << endl;
	for (int i = 1; i <= A[0]; i++) {
		cin >> A[i];
	}
	cout << "---------------------------------------------" << endl;
	cout << "����Ҫ���ҵ�ֵ:" << endl;
	cin >>x;
	cout << "---------------------------------------------" << endl;
	cout << "��ֵ�������е�λ����:";
	cout << BiSearch(A,  x,  A[0]) << endl;
	cout << "---------------------------------------------" << endl;
	return 0;
}
