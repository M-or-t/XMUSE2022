#include<iostream>
#include<stack>
#include<queue>
#include<algorithm>
using namespace std;
#define infinite 32767;
const int maxvnum = 32767;
const int maxanum = 100;
bool visited[maxvnum];
stack<int>s;
typedef struct arcnode {
	int adjvex;
	struct arcnode* next;
}acrnode;//�߱����
typedef struct vnode {
	char vex;
	arcnode* firstarc;
}vnode;//��������
typedef vnode adjlist[maxanum];
typedef struct {
	adjlist vexlist;
	int vexnum, arcnum;
	int graphtype;
}graph;//ͼ����
void CreateGraph(graph*& G) {
	G = new graph;
	cout << "���붥�����ͱ���" << endl;
	cin >> G->vexnum >> G->arcnum;
	cout << "ͼ������" << endl;
	cin >> G->graphtype;
	cout << "������������㼰�����" << endl;
	for (int i = 1; i <= G->vexnum; i++) {
		cin >> G->vexlist[i].vex;
		G->vexlist[i].firstarc = nullptr;
	}
	for (int i = 1; i <= G->arcnum; i++) {
		int j;
		int k;
		cin >> j >> k;
		arcnode* temp = new arcnode;
		temp->adjvex = k;
		temp->next = G->vexlist[j].firstarc;
		G->vexlist[j].firstarc = temp;
	}//ͷ�巨���������
	cout << "-------------------------------------" << endl;
	return;
}
void showgraph(graph*& G) {
	for (int i = 1; i <= G->vexnum; i++) {
		cout << G->vexlist[i].vex << ": ";
		arcnode* p = G->vexlist[i].firstarc;
		while (p) {
			cout << p->adjvex << " ";
			p = p->next;
		}
		cout << endl;
	}
	cout << "-------------------------------------" << endl;
	return;
}
int Exist_k_path(graph* &G, int i, int j, int k)
{
    if (i == j && k == 0) return true;
    else if (k > 0)
    {
        visited[i] = 1;
        for (arcnode* p = G->vexlist[i].firstarc; p != NULL; p = p->next)
        {
			int  m = p->adjvex;
            if (!visited[m])
                if (Exist_k_path(G, m, j, k - 1)) return true;
        }
        visited[i] = 0;

    }
    return false;
}


int main() {
	graph g;
	graph* G;
	CreateGraph(G);
	showgraph(G);
	cout<<Exist_k_path(G, 2, 9, 3)<<endl;

}
