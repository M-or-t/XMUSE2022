#include<GL/glut.h>
#include<cmath>
const int N = 5;
const double pi = 3.1415926;
GLdouble color[N][3] = {
	{0,107.0/255,176.0/255},//��
	{239.0/255,169.0/255,13.0/255},//��
	{29.0/255,24.0/255,21.0/255},//��
	{5.0/255,147.0/255,65.0/255},//��
	{220.0/255,47.0/255,31.0/255}//��
};
double center[N][N] = {
	{-4.5,2},
	{-2.25,0},
	{0,2},
	{2.25,0},
	{4.5,2}
};
double depth[N][4] = {
	{-1,0,0,1},
	{0,1,-1,0},
	{0,0,2,-1},
	{2,5,-2,0},
	{0,0,8,-10},
};
const int num = 1500;
double r[2] = { 1.9,2.2 };
double ang = 2 * pi / num;
void display(){
	
	
	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LEQUAL);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glPushMatrix();


	for (int i = 0; i < N; i++) {
		glColor3d(color[i][0],color[i][1],color[i][2]);
		glBegin(GL_QUAD_STRIP);
		
		for (int j = 0; j <=num; j++) {
			int t = 0;
			t = (j + num / 8) % num / (num / 4);
			for (int k = 0; k < 2; k++) {
				double x = center[i][0] + r[k]  * cos(ang * j);
				double y = center[i][1] + r[k]  * sin(ang * j);
				
				glVertex3d(x,y,depth[i][t]);
			}
		}
		glEnd();
	}
	glFlush();
	glutSwapBuffers();
}

void reshape(int w, int h)
{
	if (h == 0) h = 1; // ��ֹ������
	float aspect = (float)w / (float)h;

	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// ʹ��glOrtho����һ�������ݺ�ȵ�����ͶӰ
	if (w >= h) {
		// ���ڿ��ȴ��ڸ߶�
		glOrtho(-10.0 * aspect, 10.0 * aspect, -10.0, 10.0, 10.0, -10.0);
	}
	else {
		// ���ڸ߶ȴ��ڿ���
		glOrtho(-10.0, 10.0, -10.0 / aspect, 10.0 / aspect, 10.0, -10.0);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void init() {
	glClearColor(1, 1, 1,0);
	
}
int main(int argc,char** arg) {
	glutInit(&argc, arg);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(500, 100);
	glutCreateWindow("FiveRings");

	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	init();
	glutMainLoop();
	return 0;
}