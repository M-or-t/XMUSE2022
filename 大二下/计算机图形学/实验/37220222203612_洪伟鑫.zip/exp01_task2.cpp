﻿#include <GL/glut.h>
#include<cmath>
const double pi = 3.1415926;
const double rot = 0.1;
GLdouble color[][3] = {
	{1.0,0.5,0},//橙色
	{1.0,0,1.0},//品红
	{0,0,1.0},//蓝
	{0,1.0,0},//绿色
	{1.0,1.0,0},//黄色
	{1.0,0,0},//红色
	{0,1.0,1.0}//青色

};
int n = 7;
int num = 150;
double x = 0;
double y = 0;
double r = 6.0;
void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glShadeModel(GL_FLAT);
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);	
	glRotatef(rot, 0, 0, 1.0);
	glPushMatrix();
	glBegin(GL_TRIANGLE_FAN);			
	glVertex2d(0, 0);
	for (int i = 0; i < n; i++) {
		glColor3dv(color[i]);
			for (int j = 0; j <= num; j++) {
				double ang = i * 2 * pi / n + j * 2 * pi / (n*num);
				double rx = x + r*cos(ang);
				double ry = y + r*sin(ang);
				glVertex2d(rx, ry);
			}
	}
	glEnd();											
	glFlush();
	glPopMatrix();
}

void reshape(int w, int h)
{
	if (h == 0) h = 1; // 防止除以零
	float aspect = (float)w / (float)h;

	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	// 使用glOrtho设置一个保持纵横比的正交投影
	if (w >= h) {
		// 窗口宽度大于高度
		glOrtho(-10.0 * aspect, 10.0 * aspect, -10.0, 10.0, 10.0, -10.0);
	}
	else {
		// 窗口高度大于宽度
		glOrtho(-10.0, 10.0, -10.0 / aspect, 10.0 / aspect, 10.0, -10.0);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void Rotate() {
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100); 
	glutCreateWindow(argv[0]);
	
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(Rotate);
	init();
	glutMainLoop();
	return 0;
}
