#include <Eigen/Core>
#include "ppm.hpp"
#include "camera.hpp"
#include "raytracer.hpp"
#include <windows.h>
#include <vector>
#include <iostream>
#include <Magick++.h>
using namespace Magick;
using namespace std;

const int width = 1280;
const int height = 960;


void drawframe(float h, int frameIndex, float sp3Height, float sp4Height,float sp5Height) {
    PPM outrlt(width, height);
    Camera cam;
    Scene world;
    Sphere sp1(Vector3f(0, h, -2), 1.0);
    Sphere sp2(Vector3f(0, -10000.5, -2), 10000.0);
    Sphere sp3(Vector3f(-2.0, sp3Height, -2), 0.5);
    Sphere sp4(Vector3f(1.0, sp4Height, -1.0), 0.3);
    Sphere sp5(Vector3f(3.0, sp5Height, -2.2), 0.4);
    Sphere sp6(Vector3f(-1, 0.0, -0.8), 0.2);

    Material mtl, mtl2, mtl3, mtl4, mtl5;
    mtl.SetKa(Vector3f(0.5, 0.5, 0.5));
    mtl.SetKd(Vector3f(0.8, 0.6, 0.0));
    mtl.SetKs(Vector3f(0.7, 0.8, 0.8));
    mtl.SetTransparent(false);
    mtl.SetReflective(true);
    mtl.SetShiness(50);

    mtl2.SetKa(Vector3f(0.5, 0.5, 0.5));
    mtl2.SetKd(Vector3f(0.0, 0.6, 0.2));
    mtl2.SetKs(Vector3f(0.1, 1.0, 0.8));
    mtl2.SetTransparent(false);
    mtl2.SetReflective(false);
    mtl2.SetShiness(10);

    mtl3.SetKa(Vector3f(0.5, 0.5, 0.5)); // ��ɫС��
    mtl3.SetKd(Vector3f(0.0, 0.3, 0.6));
    mtl3.SetKs(Vector3f(0.0, 0.0, 0.0));
    mtl3.SetTransparent(false);
    mtl3.SetReflective(false);
    mtl3.SetShiness(10);

    mtl4.SetKa(Vector3f(0.1, 0.1, 0.1)); // �Ҳ��ɫС��
    mtl4.SetKd(Vector3f(0.0, 0.0, 0.0));
    mtl4.SetKs(Vector3f(0.0, 0.0, 0.0));
    mtl4.SetTransparent(true);
    mtl4.SetReflective(false);
    mtl4.SetRefraction(1.33);
    mtl4.SetShiness(200);

    mtl5.SetKa(Vector3f(0.5, 0.5, 0.5)); // �Ҳ��ɫС��
    mtl5.SetKd(Vector3f(0.75, 0.56, 0.0));
    mtl5.SetKs(Vector3f(0.75, 0.56, 0.0));
    mtl5.SetTransparent(false);
    mtl5.SetReflective(false);
    mtl5.SetRefraction(1.33);
    mtl5.SetShiness(100);

    world.Insert(make_pair(sp1, mtl));
    world.Insert(make_pair(sp2, mtl2));
    world.Insert(make_pair(sp3, mtl3));
    world.Insert(make_pair(sp4, mtl4));
    world.Insert(make_pair(sp5, mtl5));

    for (int j = height - 1; j >= 0; --j)
    {
        for (int i = 0; i < width; ++i)
        {
            bool test = false;
            //���ɹ���
            float u = float(i) / float(width);
            float v = float(j) / float(height);
            Ray ray = cam.GenerateRay(u, v);
            Vector3f color = RayColor(ray, world, test);

            outrlt.SetPixel(j, i,
                int(255.99 * color[0]), int(255.99 * color[1]), int(255.99 * color[2]));
        }
    }

    char path[999];
    sprintf_s(path, "./Frame/frame%d.ppm", frameIndex);
    outrlt.Write2File(path);
}

int main() {
    system("md Frame");

    const int Frames = 60; // ��֡��
    const float dt = 0.1f; // ֡���
    float gravityAccel = -9.8f; // �������ٶ�
    float k = 0.52; // ��������ײ������ʧ

    float ballHeight = 4.0f; // ��ĳ�ʼ�߶�
    float ballVelocity = 0; // ��ĳ�ʼ�ٶ�
    float ballPosition = ballHeight; // ���Ĵ���ĳ�ʼλ��
    float ballVelocity0 = 0;//ǰһ֡���ٶ�

    float sp3InitialHeight = 7.0f; // sp3�ĳ�ʼ�߶�
    float sp3Velocity = 0; // sp3�ĳ�ʼ�ٶ�
    float sp3Position = sp3InitialHeight; // sp3�ĳ�ʼλ��
    float sp3Velocity0 = 0;//ǰһ֡���ٶ�

    float sp4InitialHeight = 8.0f; // sp4�ĳ�ʼ�߶�
    float sp4Velocity = 0; // sp4�ĳ�ʼ�ٶ�
    float sp4Position = sp4InitialHeight; // sp4�ĳ�ʼλ��
    float sp4Velocity0 = 0;//ǰһ֡���ٶ�

    float sp5InitialHeight = 9.0f; // sp5�ĳ�ʼ�߶�
    float sp5Velocity = 0; // sp5�ĳ�ʼ�ٶ�
    float sp5Position = sp5InitialHeight; // sp5�ĳ�ʼλ��
    float sp5Velocity0 = 0;//ǰһ֡���ٶ�

    for (int frameidx = 0; frameidx <= Frames; ++frameidx) {
        // �����ٶȺ�λ��
        ballVelocity0 = ballVelocity;
        ballVelocity += gravityAccel * dt;
        ballPosition += (ballVelocity+ ballVelocity0) * dt/2;
        sp3Velocity += gravityAccel * dt;
        sp3Position += (sp3Velocity+ sp3Velocity0)*dt/2;
        sp4Velocity += gravityAccel * dt;
        sp4Position += (sp4Velocity+ sp4Velocity0)*dt/2;
        sp5Velocity += gravityAccel * dt;
        sp5Position += (sp5Velocity+ sp5Velocity0)*dt/2;
        // �����߼�
        if (ballPosition < 0.5) {
            ballPosition = 0.5;
            ballVelocity = -ballVelocity * k;
        }
        if (sp3Position < 0) { // ����sp3�ķ������Ը��ڵ��棬���ṩ�Ӿ�����
            sp3Position = 0;
            sp3Velocity = -sp3Velocity * k;
        }
        if (sp4Position < -0.1) { // ����sp4�ķ������Ը��ڵ��棬���ṩ�Ӿ�����
            sp4Position = -0.1;
            sp4Velocity = -sp4Velocity * k;
        }
        if (sp5Position < 0) { // ����sp5�ķ������Ը��ڵ��棬���ṩ�Ӿ�����
            sp5Position = 0;
            sp5Velocity = -sp5Velocity * k;
        }

        drawframe(ballPosition, frameidx, sp3Position, sp4Position,sp5Position);
        cout << "Frame " << frameidx << " ���" << endl;
    }

    cout << "����GIFͼ��" << endl;
    vector<Image> framequeue;
    for (int frameidx = 0; frameidx <= Frames; ++frameidx) {
        char framePath[100];
        sprintf_s(framePath, "./Frame/frame%d.ppm", frameidx);
        Image frameImage(framePath);
        framequeue.push_back(frameImage);
    }

    for (auto& img : framequeue) {
        img.animationDelay(3); 
    }

    string gifFileName = "������.gif";
    writeImages(framequeue.begin(), framequeue.end(), gifFileName);
    cout << "ͼ�����ɳɹ���" << gifFileName << endl;

    system("rd /s /q Frame");

    return 0;
}