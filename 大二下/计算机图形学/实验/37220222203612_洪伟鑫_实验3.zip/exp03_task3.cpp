#include <GL/glut.h>
#include<math.h>

GLfloat beta = 0;
GLfloat rotateangle = 0;
GLfloat camX = 2.0f;
GLfloat camY = 2.0f;
GLfloat camZ = 2.0f;
bool camLock = false;
GLfloat lightpos[4] = { 1,1,1,1 };

// ������λ�ã���Χ0��1
float sliderLightIntensity = 0.5f;
float sliderAmbientValue = 0.5f;
float sliderSpecularValue = 0.5f;

// �������Ƿ��϶�
bool draggingSlider = false;
bool draggingAmbient = false;
bool draggingSpecular = false;

// ����������Ļλ�úͳߴ�
float sliderX = 50.0f, sliderY = 50.0f, sliderWidth = 100.0f, sliderHeight = 10.0f;
float sliderAmbientX = 300.0f,  sliderSpecularX = 150.0f;
float sliderAmbientY = 70.0f,  sliderSpecularY = 400.0f;


typedef struct materialStruct {
	GLfloat ambient[4];
	GLfloat diffuse[4];
	GLfloat specular[4];
	GLfloat shininess;
}materialStruct;

materialStruct brass = {
	{0.33,0.22,0.03,1.0},
	{0.78,0.57,0.11,1.0},
	{0.99,0.91,0.81,1.0},
	27.8
};

materialStruct redPlastic = {
	{0.3,0.0,0.0,1.0},
	{0.6,0.0,0.0,1.0},
	{0.8,0.6,0.6,1.0},
	32.0
};

materialStruct whiteShiny = {
	{1.0,1.0,1.0,1.0},
	{1.0,1.0,1.0,1.0},
	{1.0,1.0,1.0,1.0},
	100.0
};

void materials(materialStruct* materials) {
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, materials->ambient);
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, materials->diffuse);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, materials->specular);
	glMaterialf(GL_FRONT_AND_BACK, GL_SHININESS, materials->shininess);
}


typedef struct lightingStruct {
	GLfloat ambient[4];
	GLfloat diffuse[4];
	GLfloat specular[4];
}lightingStruct;

lightingStruct whitelighting = {
	{0,0,0,1},
	{1,1,1,1},
	{1,1,1,1}
};

lightingStruct coloredlighting = {
	{0.2,0,0,1},
	{0,1,0,1},
	{0,0,1,1}
};

void lights(lightingStruct* lighting) {
	glLightfv(GL_LIGHT0, GL_AMBIENT, lighting->ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lighting->diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, lighting->specular);
}


materialStruct* currentmaterial;
lightingStruct* currentlight;


void init(void)
{
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, lightpos);
	glClearColor(0.0, 0.0, 0.0, 0.0);

	currentmaterial = &redPlastic;
	materials(currentmaterial);
	currentlight = &whitelighting;
	lights(currentlight);

	glShadeModel(GL_SMOOTH);

	glEnable(GL_DEPTH_TEST);
}

void camlegal(double x, double y, double z) {
	if (fabs(camX - 0.5) >= 2)camX = 2.5;
	if (fabs(camY - 0.5) >= 2)camY = 2.5;
	if (fabs(camZ - 0.5) >= 2)camZ = 2.5;
}

void keyboard(unsigned char key, int x, int y) {
	float camMoveSpeed = 0.2f;
	switch (key) {
	case 27:
		exit(0);
		break;
	case 'w':
		if (!camLock) {
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
			camY -= camMoveSpeed;
		}
		break;
	case 's':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
			camY += camMoveSpeed;
		}
		break;
	case 'a':
		if (!camLock) {
			camX -= camMoveSpeed;
			camZ += camMoveSpeed;
		}
		break;
	case 'd':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'q':
		if (!camLock) {
			camY += 2 * camMoveSpeed;
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'e':
		if (!camLock) {
			camY -= 2 * camMoveSpeed;
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
		}
		break;
	case 'L':
	case 'l':
		camLock = !camLock;
		break;
	case 'b':
		currentmaterial = &brass;
		materials(currentmaterial);
		break;
	case 'n':
		currentmaterial = &redPlastic;
		materials(currentmaterial);
		break;
	case 'm':
		currentmaterial = &whiteShiny;
		materials(currentmaterial);
		break;
	case 'o':
		lights(&whitelighting);
		break;
	case 'p':
		lights(&coloredlighting);
		break;

	}

	camlegal(camX, camY, camZ);
	glutPostRedisplay();
}

void mouseMove(int x, int y) {
	if (!camLock) {
		int centerX = glutGet(GLUT_WINDOW_WIDTH) / 2;
		int centerY = glutGet(GLUT_WINDOW_HEIGHT) / 2;
		int deltaX = x - centerX;
		int deltaY = y - centerY;

		float sensitivity = 0.005f; // �����ȣ�������Ҫ����
		camX += deltaX * sensitivity;
		camY -= deltaY * sensitivity;
		camlegal(camX, camY, camZ);
		glutWarpPointer(centerX, centerY);
	}
	glutPostRedisplay(); // �����ػ洰��
}

void passiveMouseMove(int x, int y) {
	mouseMove(x, y);
}
void drawSlider(float sliderx,float slidery,float slidervalue) {
	glBegin(GL_QUADS); 
	glVertex2f(sliderx, slidery);
	glVertex2f(sliderx + sliderWidth, slidery);
	glVertex2f(sliderx + sliderWidth, slidery + sliderHeight);
	glVertex2f(sliderx, slidery + sliderHeight);
	glEnd();

	// ���ƻ���
	float knobX = sliderx + slidervalue * sliderWidth;
	glBegin(GL_QUADS);
	glVertex2f(knobX - 5, slidery - 5);
	glVertex2f(knobX + 5, slidery - 5);
	glVertex2f(knobX + 5, slidery + sliderHeight + 5);
	glVertex2f(knobX - 5, slidery + sliderHeight + 5);
	glEnd();
}

#define CHECK_AND_UPDATE_SLIDER(x, y, sliderx, slidery, draggingslider, sliderValue) \
    do { \
        if ((x) >= (sliderx) && (x) <= (sliderx) + (sliderWidth) && (y) >= (slidery) && (y) <= (slidery) + (sliderHeight)) { \
            (draggingslider) = true; \
            (sliderValue) = ((x) - (sliderx)) / (sliderWidth); \
            glutPostRedisplay(); \
        } \
    } while(0)//һ���������slider�Ƿ񱻵�����������������sliderֵ�ĺ�

void mouse(int button, int state, int x, int y) {
	// ת��y����
	y = glutGet(GLUT_WINDOW_HEIGHT) - y;
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
		// ����Ƿ����˻���
		CHECK_AND_UPDATE_SLIDER(x, y, sliderX, sliderY, draggingSlider, sliderLightIntensity);
		CHECK_AND_UPDATE_SLIDER(x, y, sliderAmbientX, sliderAmbientY, draggingAmbient, sliderAmbientValue);
		CHECK_AND_UPDATE_SLIDER(x, y, sliderSpecularX, sliderSpecularY, draggingSpecular, sliderSpecularValue);
	}
	else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {//��������ɿ�ʱҪ���϶�flag��false
		bool draggingSlider = false;
		bool draggingAmbient = false;
		bool draggingSpecular = false;

	}
}

void adjustLightIntensity() {
	GLfloat lightIntensity[] = { sliderLightIntensity, sliderLightIntensity, sliderLightIntensity, 1.0f };
	glLightfv(GL_LIGHT0, GL_DIFFUSE, lightIntensity);
}

void adjustMaterialProperties() {
	currentmaterial->ambient[0] = sliderAmbientValue;
	currentmaterial->ambient[1] = sliderAmbientValue;
	currentmaterial->ambient[2] = sliderAmbientValue;
	currentmaterial->specular[0] = sliderSpecularValue;
	currentmaterial->specular[1] = sliderSpecularValue;
	currentmaterial->specular[2] = sliderSpecularValue;
	// Ӧ���µĲ��ʲ���
	materials(currentmaterial);
}

#define UPDATE_SLIDER_VALUE(x,y, sliderValue, sliderX) \
    do { \
        (y) = glutGet(GLUT_WINDOW_HEIGHT) - (y); \
        (sliderValue) = ((x) - (sliderX)) / sliderWidth; \
        if ((sliderValue) < 0) (sliderValue) = 0; \
        if ((sliderValue) > 1) (sliderValue) = 1; \
		glutPostRedisplay();\
    } while(0)

void motion(int x, int y) {
	if (draggingSlider) {
		UPDATE_SLIDER_VALUE(x, y, sliderLightIntensity, sliderX);
	}
	if (draggingAmbient) {
		UPDATE_SLIDER_VALUE(x, y, sliderAmbientValue, sliderAmbientX);
	}

	if (draggingSpecular) {
		UPDATE_SLIDER_VALUE(x, y, sliderSpecularValue, sliderSpecularX);
	}
}

void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(camX, camY, camZ,
		0.5, 0.5, 0.5,
		0.0, 1.0, 0.0);

	glRotatef(rotateangle, 1, 1, -1);

	glBegin(GL_QUADS);
	glNormal3f(0, 0, 1.0);
	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(-1.0, -1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);//z����

	glNormal3f(0, 0, -1.0);
	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);//z����

	glNormal3f(1.0, 0, 0);
	glColor3f(0.0, 0.0, 1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);//x����

	glNormal3f(-1.0, 0, 0);
	glColor3f(1.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(-1.0, -1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, -1.0);//x����

	glNormal3f(0, 1.0, 0);
	glColor3f(1.0, 0.0, 1.0);
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(-1.0, 1.0, 1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(1.0, 1.0, -1.0);//y����

	glNormal3f(0, -1.0, 0);
	glColor3f(0.0, 1.0, 1.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(-1.0, -1.0, 1.0);//y����

	glEnd();
	adjustLightIntensity();
	adjustMaterialProperties();
	// ��3D��Ⱦ���л�������ͶӰ��ͼ����Ⱦ2D UI������
	glMatrixMode(GL_PROJECTION);
	glPushMatrix(); // ���浱ǰͶӰ����
	glLoadIdentity();
	gluOrtho2D(0.0, glutGet(GLUT_WINDOW_WIDTH), 0.0, glutGet(GLUT_WINDOW_HEIGHT));
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix(); // ���浱ǰģ����ͼ����
	glLoadIdentity();
	//���ƻ�����
	drawSlider(sliderX,sliderY,sliderLightIntensity);
	drawSlider(sliderAmbientX, sliderAmbientY,sliderAmbientValue);
	drawSlider(sliderSpecularX, sliderSpecularY, sliderSpecularValue);
	// �ָ�֮ǰ�����ģ����ͼ�����ͶӰ����
	glMatrixMode(GL_MODELVIEW);
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);

	// ��������������ʾ��Ⱦ����
	glutSwapBuffers();
}


void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}

void idlefunc()
{
	rotateangle += 0.2;
	if (rotateangle > 360) rotateangle -= 360;
	glutPostRedisplay();
}

int main(int argc, char** argv)
{

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(argv[0]);
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);
	//glutPassiveMotionFunc(passiveMouseMove);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}