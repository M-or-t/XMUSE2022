#include <GL/freeglut.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
struct Vertex {
   float x, y, z; // ���������
   float nx, ny, nz;
};
struct Face {
   int vertexs[3]; // �����涼��������
};
vector<Vertex> vertices;
vector<Face> faces;
double gx, gy, gz;
int numVertices;
int numFaces;
void display() {
   glClear(GL_COLOR_BUFFER_BIT |GL_DEPTH_BUFFER_BIT);
   for (auto t : faces) {
       glBegin(GL_TRIANGLES);
       for (int i = 0; i < 3; i++) {
           float x1, y1, z1;
           x1 = vertices[t.vertexs[i]].x;
           y1 = vertices[t.vertexs[i]].y;
           z1 = vertices[t.vertexs[i]].z;
           glVertex3f(x1, y1, z1);
       }
       glEnd();
   }//��ȡ�����������Ե�λ�ã���������������Ԫ
   glutSwapBuffers();
}

void parsePLYFile(const string& path) {
   ifstream plyFile(path);
   if (!plyFile) {
       cerr << "�Ҳ���PLY�ļ����޷���" << endl;
       return;
   }

   string currentLine;
   int numVertices = 0, numFaces = 0;
   bool headerEnded = false;

   while (getline(plyFile, currentLine)) {
       // ȷ��������������
       if (currentLine.find("element vertex") != string::npos) {
           stringstream(currentLine.substr(15)) >> numVertices;
       }
       if (currentLine.find("element face") != string::npos) {
           stringstream(currentLine.substr(13)) >> numFaces;
       }
       if (currentLine == "end_header") {
           headerEnded = true;
           break;
       }
   }

   if (!headerEnded) {
       cerr << "�ļ�ͷû�б���ȷ��ȡ��" << endl;
       return;
   }

   // ��ȡ��������
   for (int i = 0; i < numVertices; i++) {
       Vertex v;
       plyFile >> v.x >> v.y >> v.z >> v.nx >> v.ny >> v.nz;
       vertices.push_back(v);
   }
   // ��ȡ������
   for (int i = 0; i < numFaces; i++) {
       int num, idx1, idx2, idx3;
       plyFile >> num >> idx1 >> idx2 >> idx3;
       if (num != 3) {
           cerr << "�з����ǵ���" << endl;
           continue; // ���Է���������
       }
       faces.push_back({ {idx1, idx2, idx3} });
   }
   for (auto t : vertices) {
       gx += t.x;
       gy += t.y;
       gz += t.z;
   }
   gx /= vertices.size();
   gy /= vertices.size();
   gz /= vertices.size();
   plyFile.close();
}

void init()
{
   parsePLYFile("lizhenxiout.ply");
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glOrtho(-1200, 1200, -1200, 1200, -1200, 1200);
   glClearColor(1,1, 0, 0);
   glColor3f(1, 0, 1.0); 
   gluLookAt(0,0, -150, gx,gy,gz, 0, 1, 0);
}


int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glutInitWindowSize(600, 600);
   glutInitWindowPosition(500, 50);
   glutCreateWindow("��ɫС�˻���");
   init();
   glutDisplayFunc(display);
   glutMainLoop();
}
