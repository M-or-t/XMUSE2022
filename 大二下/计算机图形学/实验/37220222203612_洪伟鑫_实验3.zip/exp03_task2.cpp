#include <GL/freeglut.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
struct Vertex {
   float x, y, z; // ���������
   float nx, ny, nz;
};
struct Face {
   int vertexs[3]; // �����涼��������
};
vector<Vertex> vertices;
vector<Face> faces;
double gx, gy, gz;
int numVertices;
int numFaces;
double rotateangle = 0;
const double r = 10.0f;
// ���ù�Դ����
GLfloat light_position[] = { 0, 10, 0, 0.0 };
GLfloat rosegold_light[] = { 236.0 / 255,177.0 / 255,172.0 / 255,1.0 };
GLfloat ambient_light[] = { 0.2, 0.2, 0.2, 1.0 };

double phi = 0;
double seita = 0;


void display() {
   glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
   glEnable(GL_DEPTH_TEST);  // ������Ȳ���
   glLightfv(GL_LIGHT0, GL_POSITION, light_position);

   for (auto& face : faces) {
       glBegin(GL_TRIANGLES);
       for (int i = 0; i < 3; ++i) {
           Vertex& v = vertices[face.vertexs[i]];
           // ָ����������
           glNormal3f(v.nx, v.ny, v.nz);
           glVertex3f(v.x, v.y, v.z);
       }
       glEnd();
   }

   glutSwapBuffers();
}

void parsePLYFile(const string& path) {
   ifstream plyFile(path);
   if (!plyFile) {
       cerr << "�Ҳ���PLY�ļ����޷���" << endl;
       return;
   }

   string currentLine;
   int numVertices = 0, numFaces = 0;
   bool headerEnded = false;

   while (getline(plyFile, currentLine)) {
       // ȷ��������������
       if (currentLine.find("element vertex") != string::npos) {
           stringstream(currentLine.substr(15)) >> numVertices;
       }
       if (currentLine.find("element face") != string::npos) {
           stringstream(currentLine.substr(13)) >> numFaces;
       }
       if (currentLine == "end_header") {
           headerEnded = true;
           break;
       }
   }

   if (!headerEnded) {
       cerr << "�ļ�ͷû�б���ȷ��ȡ��" << endl;
       return;
   }

   // ��ȡ��������
   for (int i = 0; i < numVertices; i++) {
       Vertex v;
       plyFile >> v.x >> v.y >> v.z >> v.nx >> v.ny >> v.nz;
       vertices.push_back(v);
   }
   // ��ȡ������
   for (int i = 0; i < numFaces; i++) {
       int num, idx1, idx2, idx3;
       plyFile >> num >> idx1 >> idx2 >> idx3;
       if (num != 3) {
           cerr << "�з����ǵ���" << endl;
           continue; // ���Է���������
       }
       faces.push_back({ {idx1, idx2, idx3} });
   }
   for (auto t : vertices) {
       gx += t.x;
       gy += t.y;
       gz += t.z;
   }
   gx /= vertices.size();
   gy /= vertices.size();
   gz /= vertices.size();
   plyFile.close();
}

void idlefunc(){
   rotateangle += 0.01f;
   if (rotateangle > 360)rotateangle -= 360;
   light_position[0] = r * sin(rotateangle);
   light_position[1] = r;
   light_position[2] = r * cos(rotateangle);
   glutPostRedisplay();
}

void init()
{
   parsePLYFile("lizhenxiout.ply");

   glEnable(GL_LIGHTING);  // ���ù���
   glEnable(GL_LIGHT0);    // ���ù�Դ0
   glEnable(GL_NORMALIZE); // ���÷����Զ��淶��

   glLightfv(GL_LIGHT0, GL_POSITION, light_position);
   glLightfv(GL_LIGHT0, GL_DIFFUSE, rosegold_light);
   glLightfv(GL_LIGHT0, GL_SPECULAR, rosegold_light);
   glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambient_light);

   // ���ò�������
   GLfloat mat_diffuse[] = { 1, 1, 1, 1.0 };
   GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
   GLfloat mat_shininess[] = { 80.0 };

   glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_diffuse);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
   glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   glOrtho(-1200, 1200, -1200, 1200, -1200, 1200);
   glClearColor(0.5, 0.5,0.5, 1);
   glColor3f(1, 0, 1.0);
   gluLookAt(0, -0, 0, gx, gy, gz, 0, 1, 0);
}

void keyfunc(unsigned char key, int x,int y) {
   double moveangle = 3.0f;
   phi = seita = 0;
   switch (key)
   {
   case('w'):
       phi -= moveangle; break;
   case('s'):
       phi += moveangle; break;
   case('a'):
       seita -= moveangle; break;
   case('d'):
       seita += moveangle; break;
   }
   if(seita)glRotatef(seita, 0, 1, 0);
   if(phi)glRotatef(phi, 1, 0, 0);
   glutPostRedisplay();
}

int main(int argc, char** argv)
{
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
   glEnable(GL_DEPTH_TEST);  // ������Ȳ���
   glutInitWindowSize(600, 600);
   glutInitWindowPosition(500, 50);
   glutCreateWindow("����С�˻���");
   init();
   glutIdleFunc(idlefunc);
   glutKeyboardFunc(keyfunc);
   glutDisplayFunc(display);
   glutMainLoop();
}
