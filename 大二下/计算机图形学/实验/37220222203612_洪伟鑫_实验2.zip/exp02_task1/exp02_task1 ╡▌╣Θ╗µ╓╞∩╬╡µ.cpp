#include <GL/glut.h>
#include <Windows.h> 
#include<cmath>
GLfloat rotateangle = 0.1;
GLfloat t = 0;
GLfloat scale = 1;
void myinit(void)
{
   glClearColor(0.0, 0.0, 0.0, 1.0);
   glColor3f(0.0, 0.0, 1.0); 
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   gluOrtho2D(0.0, 50.0, 0.0, 50.0);
   glMatrixMode(GL_MODELVIEW);
}
void triangle(GLfloat* a, GLfloat* b, GLfloat* c) {
   glVertex2fv(a);
   glVertex2fv(b);
   glVertex2fv(c);
}
void dividetriangle(GLfloat* a, GLfloat* b, GLfloat* c, int k) {
   GLfloat ab[2], ac[2], bc[2];
   int j;
   if (k > 0) {
       for (j = 0; j < 2; j++) {
           ab[j] = (a[j] + b[j]) / 2;
           ac[j] = (a[j] + c[j]) / 2;
           bc[j] = (b[j] + c[j]) / 2;
       }

       dividetriangle(a, ab, ac, k - 1);
       dividetriangle(ab, b, bc, k - 1);
       dividetriangle(ac, bc, c, k - 1);
   }
   else {
       int q, w,e;
       q = rand() % 255;
       w = rand() % 255;
       e = rand() % 255;
       glColor3f(q/255.0,w / 255.0, e / 255.0);
       triangle(a, b, c);
   }
}
void display(void)
{
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
   GLfloat v[3][2] = { {25.0,50.0},{0,0},{50.0,0} };
   int n = 5;
   glTranslatef( 20.0f,  20.0f, 0.0f);
   glRotatef(rotateangle, 0, 0, 1);
   glScalef(scale, scale, scale);
   glTranslatef(-20.0f, -20.0f, 0.0f);
   glClear(GL_COLOR_BUFFER_BIT); 
   glBegin(GL_TRIANGLES);
   dividetriangle(v[0], v[1], v[2],n);
   glEnd();
   glutSwapBuffers();
}

void idle(void) {
   rotateangle = rotateangle + 0.1;
   if (rotateangle >= 360)rotateangle -= 360;
   t += 0.1f;
   scale = 1 + 0.5 * sin(0.05 * t);
   glutPostRedisplay();
}

void main(int argc, char** argv)
{

   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB); 
   glutInitWindowSize(500, 500); 
   glutInitWindowPosition(0, 0); 
   glutCreateWindow("Sierpinski Gasket"); 
   glutDisplayFunc(display);  
   myinit(); 
   glutIdleFunc(idle);
   glutMainLoop(); 
}