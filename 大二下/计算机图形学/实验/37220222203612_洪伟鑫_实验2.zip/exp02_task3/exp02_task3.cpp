#include <GL/glut.h>
#include<math.h>
const double pi = 3.1415926;
double r = 1.0f;
GLfloat rotateangle = 0;

GLfloat camX = 2.0f;
GLfloat camY = 2.0f;
GLfloat camZ = 2.0f;
bool camLock = false; 

void init(void)
{
	glClearColor(1.0, 1.0, 1.0, 0.0);
	glColor3f(1.0, 0.0, 0.0);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_DEPTH_TEST);
}

void camlegal(double x, double y, double z) {
	if (fabs(camX - 0.5) >= 2)camX = 2.5;
	if (fabs(camY - 0.5) >= 2)camY = 2.5;
	if (fabs(camZ - 0.5) >= 2)camZ = 2.5;
}

void keyboard(unsigned char key, int x, int y) {
	float camMoveSpeed = 0.05f;
	switch (key) {
	case 27:
		exit(0);
		break;
	case 'w':
		if (!camLock) {
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
			camY -= camMoveSpeed;
		}
		break;
	case 's':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
			camY += camMoveSpeed;
		}
		break;
	case 'a':
		if (!camLock) {
			camX -=camMoveSpeed;
			camZ +=camMoveSpeed;
		}
		break;
	case 'd':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'q':
		if (!camLock) {
			camY += 2*camMoveSpeed;
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'e':
		if (!camLock) {
			camY -= 2 * camMoveSpeed;
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
		}
		break;
	case 'L':
	case 'l':
		camLock = !camLock;
		break;
	}
	camlegal(camX, camY, camZ);
	glutPostRedisplay();
}

void mouseMove(int x, int y) {
	if (!camLock) {
		int centerX = glutGet(GLUT_WINDOW_WIDTH) / 2;
		int centerY = glutGet(GLUT_WINDOW_HEIGHT) / 2;
		int deltaX = x - centerX;
		int deltaY = y - centerY;

		float sensitivity = 0.00005f; // �����ȣ�������Ҫ����
		camX += deltaX * sensitivity;
		camY -= deltaY * sensitivity;
		camlegal(camX, camY, camZ);	
	}
	glutPostRedisplay(); // �����ػ洰��
}

void passiveMouseMove(int x, int y) {
	mouseMove(x, y);
}


void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(camX,camY,camZ,
		0.5,0.5,0.5,
		0.0, 1.0, 0.0);
	glRotatef(rotateangle, 1, 1, -1);
	glColor3f(0.2, 0.5, 1.0);
	int weixiannum = 60;
	int jingxiannum = 60;
	for (int i = 0; i <= jingxiannum; ++i)
	{
		GLfloat  seita = 2.0 * pi * i / jingxiannum;
		//ȷ����ǰ���ľ��ߵ�seita��
		glBegin(GL_LINE_STRIP);
		int weixian = 1800;
		//һ��������1800������ģ��
		for (int j = 1; j <= weixian; ++j)
		{
			GLfloat phi = pi * j / weixian;
			//phi��ʾ��ǰ��������ƽ���ڣ��㵽Բ��������y��ļн�
			GLfloat x = r * cos(seita) * sin(phi);
			GLfloat y = r * cos(phi);
			GLfloat z = r * sin(seita) * sin(phi);
			glVertex3f(x, y, z);
		}
		glEnd();
	}
	for (int i = 0; i <= weixiannum; ++i)
	{
		GLfloat  phi = pi * i / weixiannum;
		//ȷ����ǰ����γ�ߵ�phi��
		glBegin(GL_LINE_STRIP);
		int weixian = 1800;
		//һ��γ����1800����ģ��
		for (int j = 1; j <= weixian; ++j)
		{
			GLfloat seita = 2 * pi * j / weixian;
			//seita��ʾ��ǰ��������ƽ���ڣ��㵽Բ��������x��ļн�
			GLfloat x = r * cos(seita) * sin(phi);
			GLfloat y = r * cos(phi);
			GLfloat z = r * sin(seita) * sin(phi);
			glVertex3f(x, y, z);
		}
		glEnd();
	}

	glutSwapBuffers();
}

void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLfloat aspect = w * 1.0 / h;
	if (aspect >= 1)
	{
		gluPerspective(80, w * 1.0 / h, 0.1, 50);
		glMatrixMode(GL_MODELVIEW);
	}
	else
	{
		gluPerspective(80, w * 1.0 / h, 0.1, 50);
		glMatrixMode(GL_MODELVIEW);
		glScalef(aspect, aspect, aspect);
	}
	glutPostRedisplay();
}

void idlefunc()
{
	rotateangle += 0.05;
	if (rotateangle > 360) rotateangle -= 360;
	glutPostRedisplay();
}

int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(argv[0]);
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);
	glutPassiveMotionFunc(passiveMouseMove);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}
