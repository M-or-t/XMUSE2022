#include <GL/glut.h>
#include<math.h>

#define DEG_TO_RAD 0.017453

GLfloat beta = 0;
GLfloat rotateangle = 0;

GLfloat camX = 2.0f;
GLfloat camY = 2.0f;
GLfloat camZ = 2.0f;
bool camLock = false; 

void init(void)
{
	glClearColor(0.0, 0.0, 0.0, 0.0);
	glColor3f(1.0, 0.0, 0.0);


	glShadeModel(GL_SMOOTH);


	glEnable(GL_DEPTH_TEST);
}

void camlegal(double x, double y, double z) {
	if (fabs(camX - 0.5) >= 2)camX = 2.5;
	if (fabs(camY - 0.5) >= 2)camY = 2.5;
	if (fabs(camZ - 0.5) >= 2)camZ = 2.5;
}

void keyboard(unsigned char key, int x, int y) {
	float camMoveSpeed = 0.2f;
	switch (key) {
	case 27:
		exit(0);
		break;
	case 'w':
		if (!camLock) {
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
			camY -= camMoveSpeed;
		}
		break;
	case 's':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
			camY += camMoveSpeed;
		}
		break;
	case 'a':
		if (!camLock) {
			camX -=camMoveSpeed;
			camZ +=camMoveSpeed;
		}
		break;
	case 'd':
		if (!camLock) {
			camX += camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'q':
		if (!camLock) {
			camY += 2*camMoveSpeed;
			camX -= camMoveSpeed;
			camZ -= camMoveSpeed;
		}
		break;
	case 'e':
		if (!camLock) {
			camY -= 2 * camMoveSpeed;
			camX += camMoveSpeed;
			camZ += camMoveSpeed;
		}
		break;
	case 'L':
	case 'l':
		camLock = !camLock;
		break;
	}
	camlegal(camX, camY, camZ);
	glutPostRedisplay();
}

void mouseMove(int x, int y) {
	if (!camLock) {
		int centerX = glutGet(GLUT_WINDOW_WIDTH) / 2;
		int centerY = glutGet(GLUT_WINDOW_HEIGHT) / 2;
		int deltaX = x - centerX;
		int deltaY = y - centerY;

		float sensitivity = 0.005f; // �����ȣ�������Ҫ����
		camX += deltaX * sensitivity;
		camY -= deltaY * sensitivity;
		camlegal(camX, camY, camZ);
		glutWarpPointer(centerX, centerY);
	}
	glutPostRedisplay(); // �����ػ洰��
}

void passiveMouseMove(int x, int y) {
	mouseMove(x, y);
}


void display(void)
{

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(camX,camY,camZ,
		0.5,0.5,0.5,
		0.0, 1.0, 0.0);

	glRotatef(rotateangle, 1, 1, -1);

	glBegin(GL_QUADS);

	glColor3f(1.0, 0.0, 0.0);
	glVertex3f(-1.0, -1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);

	glColor3f(0.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);

	glColor3f(0.0, 0.0, 1.0); 
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, 1.0, -1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(1.0, -1.0, 1.0);

	glColor3f(1.0, 1.0, 0.0);
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(-1.0, -1.0, 1.0);
	glVertex3f(-1.0, 1.0, 1.0);
	glVertex3f(-1.0, 1.0, -1.0);

	glColor3f(1.0, 0.0, 1.0); 
	glVertex3f(-1.0, 1.0, -1.0);
	glVertex3f(-1.0, 1.0, 1.0);
	glVertex3f(1.0, 1.0, 1.0);
	glVertex3f(1.0, 1.0, -1.0);

	glColor3f(0.0, 1.0, 1.0); 
	glVertex3f(-1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, -1.0);
	glVertex3f(1.0, -1.0, 1.0);
	glVertex3f(-1.0, -1.0, 1.0);

	glEnd();

	glutSwapBuffers();
}


void reshape(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);


	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	glOrtho(-4.0, 4.0, -4.0, 4.0, -4.0, 4.0);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0.0, 0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
}


void idlefunc()
{
	rotateangle += 0.05;
	if (rotateangle > 360) rotateangle -= 360;
	glutPostRedisplay();
}



int main(int argc, char** argv)
{

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500, 500);
	glutInitWindowPosition(100, 100);
	glutCreateWindow(argv[0]);
	init();
	glutDisplayFunc(display);
	glutReshapeFunc(reshape);
	glutIdleFunc(idlefunc);
	glutPassiveMotionFunc(passiveMouseMove);
	glutKeyboardFunc(keyboard);
	glutMainLoop();
	return 0;
}
