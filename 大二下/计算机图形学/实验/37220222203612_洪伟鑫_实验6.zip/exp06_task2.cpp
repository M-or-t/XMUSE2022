﻿#include <GL/glut.h>
#include <iostream>
#include <vector>
#include <cmath>
#include <random>
using namespace std;

double t = 0.0;
int level = 3; // 贝塞尔曲线级别
const int N = 1000;
double r[N], b[N], g[N];
double r1, g1, b1;
int k = 0;
typedef struct point {
    double x, y, z;
} point;
bool isDragging = false; // 是否正在拖动
int selectedPoint[2] = { -1, -1 }; // 当前选中的控制点索引，初始化为-1
vector<vector<point>> controlPoints(5);
vector<vector<point>> Curve(5); // 用来记录贝塞尔曲线上的点
vector<vector<point>> Curve1;

void randomColor(double& r1, double& g1, double& b1) {
    // 生成随机颜色值
    r1 = rand() / (double)RAND_MAX;
    g1 = rand() / (double)RAND_MAX;
    b1 = rand() / (double)RAND_MAX;
}

bool flag = true; // 用来判断是绘制行贝塞尔曲线还是列贝塞尔曲线

// de Casteljau算法实现，用于计算贝塞尔曲线上的点
void deCasteljau(vector<point> temppoints, int templevel, int index, double u) {
    if (templevel == 1) {
        glPointSize(10);
        glBegin(GL_POINTS);
        double tx = temppoints[0].x * (1 - t) + temppoints[1].x * t;
        double ty = temppoints[0].y * (1 - t) + temppoints[1].y * t;
        double tz = temppoints[0].z * (1 - t) + temppoints[1].z * t;
        // Calculate color based on position
        double r_color = (1 - u) * r[0] + u * r[1];
        double g_color = (1 - u) * g[0] + u * g[1];
        double b_color = (1 - u) * b[0] + u * b[1];
        glColor3f(r_color, g_color, b_color);
        glVertex3f(tx, ty, tz);
        glEnd();
        if (flag)
            Curve[index].push_back({ tx, ty, tz });
        else
            Curve1[index].push_back({ tx, ty, tz });
        return;
    }
    else {
        vector<point> pp;
        glLineWidth(1);
        glColor3f(r[templevel], g[templevel], b[templevel]);
        glBegin(GL_LINE_STRIP);
        for (int i = 0; i <= templevel; i++) {
            glVertex3f(temppoints[i].x, temppoints[i].y, temppoints[i].z);
        }
        glEnd();

        for (int i = 0; i < templevel; i++) {
            double tx = temppoints[i].x * (1 - t) + temppoints[i + 1].x * t;
            double ty = temppoints[i].y * (1 - t) + temppoints[i + 1].y * t;
            double tz = temppoints[i].z * (1 - t) + temppoints[i + 1].z * t;
            pp.push_back({ tx, ty, tz });
        }
        deCasteljau(pp, templevel - 1, index, u);
    }
}

void display() {
    glEnable(GL_DEPTH_TEST);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    gluLookAt(0, 2, 4, 0, 0, 0, 0, 1, 0);
    glShadeModel(GL_SMOOTH);

    // 绘制控制点
    glPointSize(10);
    glColor3f(1, 1, 1);
    glBegin(GL_POINTS);
    for (int i = 0; i <= level; i++) {
        for (int j = 0; j <= level; j++) {
            glVertex3f(controlPoints[i][j].x, controlPoints[i][j].y, controlPoints[i][j].z);
        }
    }
    glEnd();

    flag = true;
    for (int i = 0; i <= level; i++) {
        deCasteljau(controlPoints[i], level, i, (double)i / level);
    }

    Curve1.resize(Curve[0].size());
    for (auto& row : Curve1) {
        row.resize(level);
    }
    flag = false;

    glLineWidth(6);
    glColor3f(1.0, 0, 0);

    for (int i = 0; i < Curve[0].size(); i++) {
        vector<point> temp;
        for (int j = 0; j <= level; j++) {
            temp.push_back({ Curve[j][i].x, Curve[j][i].y, Curve[j][i].z });
        }
        deCasteljau(temp, level, i, (double)i / Curve[0].size());
    }

    for (int i = 0; i < Curve1.size(); i++) {
        glBegin(GL_LINE_STRIP);
        for (auto t : Curve1[i]) {
            double u = (double)i / Curve1.size();
            double r_color = (1 - u) * r[0] + u * r[1];
            double g_color = (1 - u) * g[0] + u * g[1];
            double b_color = (1 - u) * b[0] + u * b[1];
            glColor3f(r_color, g_color, b_color);
            glVertex3f(t.x, t.y, t.z);
        }
        glEnd();
    }

    glFlush();
}

void idle() {
    t += 0.0005; // 控制移动的速度
    if (t > 1.0) {
        t = 0.0; // 当t超过1时，重置为0，使点重新开始移动
        Curve.clear(); // 清空贝塞尔曲线轨迹
        Curve1.clear();
        Curve.resize(5); // 重新分配内存
        Curve1.resize(5); // 重新分配内存
    }
    glutPostRedisplay();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    glEnable(GL_DEPTH_TEST);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, 1.0, 1.0, 10.0);
    glMatrixMode(GL_MODELVIEW);

    for (int i = 0; i < N; i++) {
        randomColor(r1, g1, b1);
        r[i] = r1;
        g[i] = g1;
        b[i] = b1;
    }
    cout << "要生成的贝塞尔曲面控制点个数为t*t,请输入t" << endl;
    cin >> level;
    level--;
    controlPoints[0].push_back({ -0.9, -0.9, -0.9 });
    controlPoints[0].push_back({ -0.4, -0.9, -0.9 });
    controlPoints[0].push_back({ 0, -0.9, -0.9 });
    controlPoints[0].push_back({ 0.4, -0.9, -0.9 });
    controlPoints[0].push_back({ 0.9, -0.9, -0.9 });
    controlPoints[1].push_back({ -0.9, -0.9, -0.4 });
    controlPoints[1].push_back({ -0.4, 0, -0.4 });
    controlPoints[1].push_back({ 0, 0, -0.4 });
    controlPoints[1].push_back({ 0.4, 0, -0.4 });
    controlPoints[1].push_back({ 0.9, -0.9, -0.4 });
    controlPoints[2].push_back({ -0.9, -0.9, 0 });
    controlPoints[2].push_back({ -0.4, 0, 0 });
    controlPoints[2].push_back({ 0, 0.5, 0 });
    controlPoints[2].push_back({ 0.4, 0, 0 });
    controlPoints[2].push_back({ 0.9, -0.9, 0 });
    controlPoints[3].push_back({ -0.9, -0.9, 0.4 });
    controlPoints[3].push_back({ -0.4, 0, 0.4 });
    controlPoints[3].push_back({ 0, 0, 0.4 });
    controlPoints[3].push_back({ 0.4, 0, 0.4 });
    controlPoints[3].push_back({ 0.9, -0.9, 0.4 });
    controlPoints[4].push_back({ -0.9, -0.9, 0.9 });
    controlPoints[4].push_back({ -0.4, -0.9, 0.9 });
    controlPoints[4].push_back({ 0, -0.9, 0.9 });
    controlPoints[4].push_back({ 0.4, -0.9, 0.9 });
    controlPoints[4].push_back({ 0.9, -0.9, 0.9 });
}
void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN) {
            // 把鼠标坐标转换为OpenGL坐标
            double mouseX = 2.0 * x / glutGet(GLUT_WINDOW_WIDTH) - 1.0;
            double mouseY = -2.0 * y / glutGet(GLUT_WINDOW_HEIGHT) + 1.0;

            // 查找最近的控制点
            double minDist = 1.0; // 最小距离阈值
            for (int i = 0; i < controlPoints.size(); ++i) {
                for (int j = 0; j < controlPoints[i].size(); ++j) {
                    double dx = mouseX - controlPoints[i][j].x;
                    double dy = mouseY - controlPoints[i][j].y;
                    double dist = sqrt(dx * dx + dy * dy);
                    if (dist < minDist) {
                        selectedPoint[0] = i;
                        selectedPoint[1] = j;
                        minDist = dist;
                        isDragging = true;
                    }
                }
            }
        }
        else if (state == GLUT_UP) {
            isDragging = false;
            selectedPoint[0] = -1;
            selectedPoint[1] = -1;
        }
    }
}
void motion(int x, int y) {
    if (isDragging && selectedPoint[0] != -1 && selectedPoint[1] != -1) {
        // 把鼠标坐标转换为OpenGL坐标
        double mouseX = 2.0 * x / glutGet(GLUT_WINDOW_WIDTH) - 1.0;
        double mouseY = -2.0 * y / glutGet(GLUT_WINDOW_HEIGHT) + 1.0;

        controlPoints[selectedPoint[0]][selectedPoint[1]].x = mouseX;
        controlPoints[selectedPoint[0]][selectedPoint[1]].y = mouseY;

        glutPostRedisplay(); // 请求重绘
    }
}
int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("贝塞尔曲面");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutMouseFunc(mouse);
    glutMotionFunc(motion);
    glutMainLoop();
    return 0;
}
