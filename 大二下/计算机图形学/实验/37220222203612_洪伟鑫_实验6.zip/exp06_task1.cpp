#include <GL/glut.h>
#include<iostream>
#include<vector>
#include<cmath>
#include<random>
using namespace std;

double t = 0.0;
int level = 3;//���������߼���
const int N = 1000;
double r[N], b[N], g[N];
double r1, g1, b1;
int k = 0;
vector<pair<float,float>>controlPoints;
vector<pair<float, float>>Curve;//������¼�����������ϵĵ�
void randomColor(double& r1, double& g1, double& b1) {
    // ���������ɫֵ
    r1 = rand() / (double)RAND_MAX;
    g1 = rand() / (double)RAND_MAX;
    b1 = rand() / (double)RAND_MAX;
}
// de Casteljau�㷨ʵ�֣����ڼ��㱴���������ϵĵ�
void deCasteljau(vector<pair<float,float>>temppoints,int templevel) {
    if (templevel==1) {
        glPointSize(10);
        glBegin(GL_POINT);
        double x = temppoints[0].first * (1 - t) + temppoints[1].first * t;
        double y = temppoints[0].second * (1 - t) + temppoints[1].second * t;
        glVertex2f(x, y);
        glEnd();
        Curve.push_back({x,y});
        return;
    }
    else {
        vector<pair<float, float>>pp;
        glLineWidth(3);
        glColor3f(r[templevel], g[templevel], b[templevel]);
        glBegin(GL_LINE_STRIP);
        for (int i = 0; i < templevel + 1; i++) {
            glVertex2f(temppoints[i].first, temppoints[i].second);
        }
        glEnd();

        for (int i = 0; i < templevel; i++) {
            double x = temppoints[i].first * (1 - t) + temppoints[i+1].first * t;
            double y = temppoints[i].second * (1 - t) + temppoints[i+1].second * t;
            pp.push_back({ x,y });
        }
        deCasteljau(pp, templevel - 1);
    }
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);

    // ���ƿ��Ƶ�
    glPointSize(10);

    glBegin(GL_POINTS);
    for (int i = 0; i <= level; i++) {
        glVertex2f(controlPoints[i].first, controlPoints[i].second);
    }
    glEnd();

    deCasteljau(controlPoints, level);


    glLineWidth(6);
    glColor3f(1.0, 0, 0);
    glBegin(GL_LINE_STRIP);
    for (auto t : Curve) {
        glVertex2f(t.first, t.second);
    }
    glEnd();

    glFlush();
}

void idle() {
    t += 0.00005; // �����ƶ����ٶ�
    if (t > 1.0) {
        t = 0.0; // ��t����1ʱ������Ϊ0��ʹ�����¿�ʼ�ƶ�
        Curve.clear();//��ձ��������߹켣
    }
    glutPostRedisplay();
}

void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
    for (int i = 0; i < N; i++) {
        randomColor(r1, g1, b1);
        r[i] = r1;
        g[i] = g1;
        b[i] = b1;
    }
    cout << "������Ҫ���ɵı����������Ǽ��׵�" << endl;
    cin >> level;    
    controlPoints.push_back({ -0.8,0.4 });
    controlPoints.push_back({ -0.4,0.8 });
    controlPoints.push_back({ 0.4,0.8 });
    controlPoints.push_back({ 0.8,0.4 });
    controlPoints.push_back({ 0.8,-0.4 });
    controlPoints.push_back({ 0.4,-0.8 });
    controlPoints.push_back({ -0.4,-0.8 });
    controlPoints.push_back({ -0.8,-0.4 });//�����Ƶ����ó�ʼ��λ��
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
        float mouseX = (x / (float)glutGet(GLUT_WINDOW_WIDTH)) * 2.0 - 1.0;
        float mouseY = 1.0 - (y / (float)glutGet(GLUT_WINDOW_HEIGHT)) * 2.0;
        // ��������Ŀ��Ƶ�
        for (int i = 0; i < controlPoints.size(); ++i) {
            float dx = mouseX - controlPoints[i].first;
            float dy = mouseY - controlPoints[i].second;
            if (sqrt(dx * dx + dy * dy) < 0.05) { // �趨һ��ѡ����ֵ
                k = i; // ��¼ѡ�еĿ��Ƶ�����
                return;
            }
        }
    }
    else if (button == GLUT_LEFT_BUTTON && state == GLUT_UP) {
        // ����ͷ�ʱȡ��ѡ��
        k = -1;
    }
}

// ����ƶ��¼���������
void motion(int x, int y) {
    if (k >= 0) {
        // ����ѡ�п��Ƶ��λ��
        controlPoints[k].first = (x / (float)glutGet(GLUT_WINDOW_WIDTH)) * 2.0 - 1.0;
        controlPoints[k].second = 1.0 - (y / (float)glutGet(GLUT_WINDOW_HEIGHT)) * 2.0;
        glutPostRedisplay(); // �����ػ�
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("����������");
    init();
    glutDisplayFunc(display);
    glutIdleFunc(idle);
    glutMouseFunc(mouse); 
    glutMotionFunc(motion);
    glutMainLoop();
}